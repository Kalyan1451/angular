import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DataserviceService } from './dataservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'sample';
  UserData:any;
  userDataFormGroup!:FormGroup;
  enableButton:boolean=true;
  constructor(private formBuild:FormBuilder,private dataSer:DataserviceService,private router:Router){
    this.prepareForm();
  }
  ngOnInit(): void {
    this.dataSer.getData().subscribe((res:any)=>{
      this.UserData=res;
      localStorage.setItem('userData',this.UserData);
    })
  }
  prepareForm(){
     this.userDataFormGroup=this.formBuild.group({
      username:['',Validators.required],
      password:['',Validators.required]
     })
  }
  navigateToDashBoard(){
    if(this.UserData.username==this.userDataFormGroup.controls['username'].value && this.UserData.password==this.userDataFormGroup.controls['password'].value && this.userDataFormGroup.controls['username'].valid && this.userDataFormGroup.controls['password'].valid){
      this.enableButton=false;
      this.router.navigate(['/dashboard']);
    }else{
      this.enableButton=true;
    }
  }
}
